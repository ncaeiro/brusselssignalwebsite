
import React from 'react';
import { NewsItem } from '../types.ts';

interface ArticleDetailProps {
  article: NewsItem;
}

const ArticleDetail: React.FC<ArticleDetailProps> = ({ article }) => {
  return (
    <main className="bg-white flex-grow">
      {/* Article Header */}
      <div className="container mx-auto px-4 md:px-6 lg:px-8 py-10 lg:py-16">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6 flex items-center gap-4">
            <span className="bg-red-600 text-white px-3 py-1 text-xs font-black uppercase tracking-widest">{article.category || 'NEWS'}</span>
            <span className="text-gray-400 text-xs font-bold uppercase">{article.date}</span>
          </div>

          <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl font-bold leading-tight mb-8">
            {article.title}
          </h1>

          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-y border-gray-100 py-6 mb-12">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-gray-200 overflow-hidden flex items-center justify-center font-bold text-gray-400 uppercase">
                {article.author ? article.author.charAt(0) : 'A'}
              </div>
              <div>
                <p className="text-xs font-black text-red-600 uppercase tracking-widest">{article.author || 'Brussels Signal Staff'}</p>
                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-tight">European Correspondent</p>
              </div>
            </div>
            
            <div className="flex gap-4">
              <button className="p-2 bg-gray-50 rounded-full hover:bg-gray-100 transition"><div className="w-5 h-5 bg-blue-600/20 rounded-sm"></div></button>
              <button className="p-2 bg-gray-50 rounded-full hover:bg-gray-100 transition"><div className="w-5 h-5 bg-sky-400/20 rounded-sm"></div></button>
              <button className="p-2 bg-gray-50 rounded-full hover:bg-gray-100 transition"><div className="w-5 h-5 bg-gray-400/20 rounded-sm"></div></button>
            </div>
          </div>

          <figure className="mb-12">
            <img 
              src={article.imageUrl} 
              alt={article.title} 
              className="w-full h-auto rounded shadow-2xl" 
            />
            <figcaption className="text-xs text-gray-500 mt-4 italic">
              {article.title}. © Brussels Signal
            </figcaption>
          </figure>

          <div className="prose prose-lg max-w-none text-gray-800 leading-relaxed font-serif">
            <p className="text-xl md:text-2xl font-bold text-gray-900 mb-8 leading-snug">
              {article.summary || "Latest reports from Brussels indicate a major shift in the continent's political landscape, as key stakeholders navigate emerging challenges across the European Union."}
            </p>

            <p className="mb-6">
              WARSAW & BRUSSELS — In an era of increasing geopolitical uncertainty, the decisions made today in the heart of Europe carry weight that resonates far beyond the continent's borders. The current situation highlights the intricate balance between national interests and collective security.
            </p>

            <p className="mb-6">
              "We are seeing a new chapter in European diplomacy," noted a senior diplomatic source. "The speed at which these events are unfolding requires a level of agility that our institutions are still learning to master. It is not just about policy; it's about the fundamental values that bind us together."
            </p>

            <blockquote className="border-l-4 border-red-600 pl-8 py-4 my-12 italic text-2xl text-gray-700">
              "The current challenges demand more than just words; they demand a unified and decisive European response."
            </blockquote>

            <p className="mb-6 font-sans text-base">
              Economic analysts are closely watching the market reactions, which have shown significant volatility following the latest announcements. The integration of technology and industrial policy remains a central theme in the ongoing debates within the European Parliament.
            </p>

            <p className="mb-6">
              As we move forward, the focus remains on transparency and the preservation of democratic norms. The dialogue between member states continues to be the primary engine of progress, even as external pressures test the limits of cooperation.
            </p>

            <h3 className="font-sans font-bold text-2xl text-gray-900 mt-12 mb-6 uppercase tracking-tight">The Road Ahead</h3>

            <p className="mb-6">
              Military and strategic considerations are also coming to the forefront, particularly on the eastern flank. The deployment of new security measures across border zones reflects a heightened state of awareness regarding asymmetrical threats.
            </p>

            <div className="bg-gray-50 p-8 rounded border-l-4 border-gray-900 my-12">
               <h4 className="font-sans font-black text-sm mb-4 uppercase">Related Coverage</h4>
               <ul className="space-y-4">
                  <li><a href="#" className="text-red-600 font-bold hover:underline">Nordic airports reopen as police probe mystery drones</a></li>
                  <li><a href="#" className="text-red-600 font-bold hover:underline">Is EU defence a von der Leyen fantasy?</a></li>
               </ul>
            </div>

            <p className="mb-6">
              In conclusion, the coming months will likely be defined by how Europe chooses to project its power on the global stage. Whether through economic leverage or diplomatic influence, the Signal will continue to provide in-depth analysis of these pivotal moments.
            </p>
          </div>

          <div className="mt-16 pt-8 border-t border-gray-100 flex items-center justify-between">
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-gray-100 text-[10px] font-bold uppercase rounded hover:bg-gray-200 cursor-pointer">EUROPE</span>
              <span className="px-3 py-1 bg-gray-100 text-[10px] font-bold uppercase rounded hover:bg-gray-200 cursor-pointer">POLITICS</span>
              <span className="px-3 py-1 bg-gray-100 text-[10px] font-bold uppercase rounded hover:bg-gray-200 cursor-pointer">ANALYSIS</span>
            </div>
            <button className="text-xs font-black text-red-600 uppercase hover:underline">Report a correction</button>
          </div>
        </div>
      </div>
    </main>
  );
};

export default ArticleDetail;
