
import React from 'react';
import { NewsItem } from '../types.ts';

interface SectionGridProps {
  title: string;
  items: NewsItem[];
  onItemClick?: (item: NewsItem) => void;
  onHeaderClick?: () => void;
}

const SectionGrid: React.FC<SectionGridProps> = ({ title, items, onItemClick, onHeaderClick }) => {
  return (
    <div>
      <div className="flex justify-between items-center border-b-2 border-gray-900 pb-2 mb-6">
        <h2 className="text-xl font-bold uppercase tracking-tight flex items-center gap-2 cursor-pointer group" onClick={onHeaderClick}>
            <span className="w-6 h-6 bg-red-600 inline-block transition-transform group-hover:scale-110"></span>
            <span className="group-hover:text-red-600 transition-colors">{title}</span>
        </h2>
        <button onClick={onHeaderClick} className="text-xs font-bold text-gray-500 hover:text-black">View All</button>
      </div>
      
      <div className="space-y-8">
        {items.map((item, idx) => (
          <div key={item.id} className="flex gap-4 group cursor-pointer" onClick={() => onItemClick?.(item)}>
            <img src={item.imageUrl} alt={item.title} className="w-28 h-20 object-cover flex-shrink-0" />
            <div>
              <h3 className="text-sm font-bold leading-snug group-hover:text-blue-800 transition-colors">
                {item.title}
              </h3>
              <p className="text-[10px] text-gray-500 mt-2 uppercase font-bold">
                <span className="text-red-600">NEWS</span> {item.date}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SectionGrid;
