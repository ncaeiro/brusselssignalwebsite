
import React from 'react';

interface HeroProps {
  onClick?: () => void;
}

const Hero: React.FC<HeroProps> = ({ onClick }) => {
  return (
    <article onClick={onClick} className="group cursor-pointer">
      <div className="relative overflow-hidden mb-4">
        <img 
          src="https://picsum.photos/seed/diplomacy_hero/1200/675" 
          alt="Featured Political Article" 
          className="w-full h-auto transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute bottom-4 left-4">
            <span className="bg-red-600 text-white px-2 py-1 text-[10px] font-bold uppercase">NEWS 12 SEP 2025</span>
        </div>
      </div>
      
      <h1 className="font-serif text-3xl md:text-5xl font-bold leading-tight mb-4 group-hover:text-blue-900 transition-colors">
        Poland rebuffs Trump suggestion that Russian drone incursion a ‘possible accident’
      </h1>
      
      <p className="text-lg text-gray-700 leading-relaxed mb-4">
        Polish Prime Minister Donald Tusk yesterday rejected speculation that the incursion into Polish airspace by around 20 Russian drones was accidental. “We are identifying those who, whether for political reasons, stupidity or betrayal, serve Russian propaganda and disinformation.”
      </p>
      
      <div className="flex items-center gap-3">
        <p className="text-sm font-bold text-red-600 uppercase tracking-widest">
          Krzysztof Mularczyk
        </p>
        <div className="w-1 h-1 bg-gray-300 rounded-full"></div>
        <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">
          3 MIN READ
        </p>
      </div>
    </article>
  );
};

export default Hero;
