
import React, { useRef } from 'react';
import { NewsItem } from '../types.ts';

interface VideoFeedProps {
  onItemClick?: (item: NewsItem) => void;
}

const VideoFeed: React.FC<VideoFeedProps> = ({ onItemClick }) => {
    const scrollRef = useRef<HTMLDivElement>(null);

    const videos = [
        {
            id: 'vf1',
            title: "Britain's Tyranny Exposed: Carl Benjamin on Protests, Elites & Nationalism",
            date: "12 SEP 2025",
            imageUrl: "https://picsum.photos/seed/political_debate_1/800/450"
        },
        {
            id: 'vf2',
            title: "Von der Leyen's Spin vs Reality: What she didn't tell you in her state of the union speech",
            date: "11 SEP 2025",
            imageUrl: "https://picsum.photos/seed/parliament_floor/800/450"
        },
        {
            id: 'vf3',
            title: "Is EU defence a von der Leyen fantasy?",
            date: "5 SEP 2025",
            imageUrl: "https://picsum.photos/seed/military_summit/800/450"
        },
        {
            id: 'vf4',
            title: "The decline of German industry: A warning to Europe",
            date: "3 SEP 2025",
            imageUrl: "https://picsum.photos/seed/factory_politics/800/450"
        },
        {
            id: 'vf5',
            title: "Farmers vs Brussels: The fight for the heart of Europe",
            date: "1 SEP 2025",
            imageUrl: "https://picsum.photos/seed/tractor_protest/800/450"
        }
    ];

    const scroll = (direction: 'left' | 'right') => {
        if (scrollRef.current) {
            const { scrollLeft, clientWidth } = scrollRef.current;
            const scrollTo = direction === 'left' ? scrollLeft - clientWidth : scrollLeft + clientWidth;
            scrollRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
        }
    };

    return (
        <div className="relative group/section">
            <div className="flex justify-between items-center border-b-2 border-red-600 pb-2 mb-6">
                <h2 className="text-xl font-bold uppercase tracking-tight flex items-center gap-2">
                    <svg className="w-6 h-6 text-red-600" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                    Video Feed
                </h2>
                <div className="hidden md:flex gap-2">
                    <button 
                        onClick={() => scroll('left')}
                        className="p-2 border border-gray-300 rounded hover:bg-gray-100 transition"
                    >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"></path></svg>
                    </button>
                    <button 
                        onClick={() => scroll('right')}
                        className="p-2 border border-gray-300 rounded hover:bg-gray-100 transition"
                    >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path></svg>
                    </button>
                </div>
            </div>
            
            <div 
                ref={scrollRef}
                className="flex gap-6 overflow-x-auto no-scrollbar snap-x snap-mandatory pb-4"
            >
                {videos.map(vid => (
                    <div key={vid.id} className="flex-none w-[85vw] md:w-[calc(33.333%-1rem)] snap-start group cursor-pointer" onClick={() => onItemClick?.(vid)}>
                        <div className="relative aspect-video overflow-hidden">
                            <img src={vid.imageUrl} className="w-full h-full object-cover transition-transform group-hover:scale-105" alt={vid.title} />
                            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                                <div className="bg-white/90 rounded-full p-4 transform transition-transform group-hover:scale-110">
                                    <svg className="w-8 h-8 text-red-600" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                                </div>
                            </div>
                        </div>
                        <div className="mt-4">
                            <p className="text-[10px] text-gray-500 uppercase font-bold mb-1">
                                <span className="text-red-600">VIDEO</span> {vid.date}
                            </p>
                            <h3 className="font-serif text-lg font-bold leading-tight group-hover:text-blue-900 line-clamp-2">
                                {vid.title}
                            </h3>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default VideoFeed;
