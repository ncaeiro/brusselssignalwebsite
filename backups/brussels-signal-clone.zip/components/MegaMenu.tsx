
import React from 'react';
import { NewsItem } from '../types.ts';

interface MegaMenuProps {
  onClose: () => void;
  onCategoryClick?: (category: string) => void;
  onPodcastClick?: (article: NewsItem) => void;
  onNewslettersClick?: () => void;
}

const MegaMenu: React.FC<MegaMenuProps> = ({ onClose, onCategoryClick, onPodcastClick, onNewslettersClick }) => {
  // Mock podcast articles for visual display in the menu
  const mockPodcasts: NewsItem[] = [
    {
      id: 'pod-int-1',
      title: 'The Battle for the Airwaves',
      podcastSeries: 'Interference',
      date: '14 SEP 2025',
      imageUrl: 'https://picsum.photos/seed/pod1/400/400',
      summary: 'Justin Stares and Alexandra Phillips discuss the latest in EU media interference.'
    },
    {
      id: 'pod-hor-1',
      title: 'Global Realignments and Europe',
      podcastSeries: 'Horizon Podcast',
      date: '12 SEP 2025',
      imageUrl: 'https://picsum.photos/seed/pod2/400/400',
      summary: 'Ralph Schoellhammer looks at the shifting geopolitical sands.'
    },
    {
      id: 'pod-ham-1',
      title: 'The Cost of Bureaucracy',
      podcastSeries: 'Hammer Time',
      date: '10 SEP 2025',
      imageUrl: 'https://picsum.photos/seed/pod3/400/400',
      summary: 'Ralph Schoellhammer on why Brussels red tape is killing industry.'
    },
    {
      id: 'pod-int-2',
      title: 'Shadow Lobbying in the Bubble',
      podcastSeries: 'Interference',
      date: '08 SEP 2025',
      imageUrl: 'https://picsum.photos/seed/pod4/400/400',
      summary: 'Uncovering the hidden influencers in the European Parliament.'
    },
    {
      id: 'pod-hor-2',
      title: 'The New Silk Road Dilemma',
      podcastSeries: 'Horizon Podcast',
      date: '05 SEP 2025',
      imageUrl: 'https://picsum.photos/seed/pod5/400/400',
      summary: 'How Europe navigates Chinese investment and security concerns.'
    },
    {
      id: 'pod-ham-2',
      title: 'Agricultural Sovereignty',
      podcastSeries: 'Hammer Time',
      date: '01 SEP 2025',
      imageUrl: 'https://picsum.photos/seed/pod6/400/400',
      summary: 'Why the CAP reform is failing the local farmer.'
    }
  ];

  const handleNewsletterNav = () => {
    onNewslettersClick?.();
    onClose();
  };

  return (
    <div className="absolute top-full left-0 w-full bg-[#121c2d]/95 backdrop-blur-md border-t border-white/10 text-white shadow-2xl z-50 overflow-y-auto max-h-[90vh]">
      <div className="container mx-auto px-4 lg:px-8 py-10">
        
        {/* Top Grid: Categories, Authors & Other */}
        <div className="flex flex-wrap lg:flex-nowrap gap-8 mb-12">
          
          {/* Categories Section (Left side) */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 flex-grow">
            {/* Politics */}
            <div>
              <button onClick={() => onCategoryClick?.('Politics')} className="text-red-500 font-black text-sm mb-6 tracking-wider uppercase hover:underline">POLITICS</button>
              <ul className="text-[11px] space-y-3 font-semibold text-gray-200">
                <li><button onClick={() => onCategoryClick?.('Politics')} className="hover:text-red-400 transition-colors text-left">EU bubble (lobbying, institutions, industry)</button></li>
                <li><button onClick={() => onCategoryClick?.('Politics')} className="hover:text-red-400 transition-colors text-left">From the capitals</button></li>
                <li><button onClick={() => onCategoryClick?.('Politics')} className="hover:text-red-400 transition-colors text-left">Elections</button></li>
                <li><button onClick={() => onCategoryClick?.('Politics')} className="hover:text-red-400 transition-colors text-left">Corruption</button></li>
                <li><button onClick={() => onCategoryClick?.('Politics')} className="hover:text-red-400 transition-colors text-left">Bureaucracy</button></li>
              </ul>
            </div>
            
            {/* Economy */}
            <div>
              <button onClick={() => onCategoryClick?.('Economy')} className="text-red-500 font-black text-sm mb-6 tracking-wider uppercase hover:underline">ECONOMY</button>
              <ul className="text-[11px] space-y-3 font-semibold text-gray-200">
                <li><button onClick={() => onCategoryClick?.('Economy')} className="hover:text-red-400 transition-colors text-left">Finance</button></li>
                <li><button onClick={() => onCategoryClick?.('Economy')} className="hover:text-red-400 transition-colors text-left">Tech</button></li>
                <li><button onClick={() => onCategoryClick?.('Economy')} className="hover:text-red-400 transition-colors text-left">Energy & Climate</button></li>
                <li><button onClick={() => onCategoryClick?.('Economy')} className="hover:text-red-400 transition-colors text-left">Trade</button></li>
                <li><button onClick={() => onCategoryClick?.('Economy')} className="hover:text-red-400 transition-colors text-left">Industrial policy</button></li>
              </ul>
            </div>

            {/* Society */}
            <div>
              <button onClick={() => onCategoryClick?.('Society')} className="text-red-500 font-black text-sm mb-6 tracking-wider uppercase hover:underline">SOCIETY</button>
              <ul className="text-[11px] space-y-3 font-semibold text-gray-200">
                <li><button onClick={() => onCategoryClick?.('Society')} className="hover:text-red-400 transition-colors text-left">Free speech</button></li>
                <li><button onClick={() => onCategoryClick?.('Society')} className="hover:text-red-400 transition-colors text-left">Migration</button></li>
                <li><button onClick={() => onCategoryClick?.('Society')} className="hover:text-red-400 transition-colors text-left">Culture War</button></li>
                <li><button onClick={() => onCategoryClick?.('Society')} className="hover:text-red-400 transition-colors text-left">Consumer rights</button></li>
                <li><button onClick={() => onCategoryClick?.('Society')} className="hover:text-red-400 transition-colors text-left">Democracy</button></li>
                <li><button onClick={() => onCategoryClick?.('Society')} className="hover:text-red-400 transition-colors text-left">Living in Brussels</button></li>
              </ul>
            </div>

            {/* World */}
            <div>
              <button onClick={() => onCategoryClick?.('Politics')} className="text-red-500 font-black text-sm mb-6 tracking-wider uppercase hover:underline">WORLD</button>
              <ul className="text-[11px] space-y-3 font-semibold text-gray-200">
                <li><button onClick={() => onCategoryClick?.('Politics')} className="hover:text-red-400 transition-colors text-left">War</button></li>
                <li><button onClick={() => onCategoryClick?.('Politics')} className="hover:text-red-400 transition-colors text-left">US</button></li>
                <li><button onClick={() => onCategoryClick?.('Politics')} className="hover:text-red-400 transition-colors text-left">China</button></li>
                <li><button onClick={() => onCategoryClick?.('Politics')} className="hover:text-red-400 transition-colors text-left">International institutions</button></li>
                <li><button onClick={() => onCategoryClick?.('Politics')} className="hover:text-red-400 transition-colors text-left">Rest of the world</button></li>
              </ul>
            </div>

            {/* Opinion */}
            <div>
              <button onClick={() => onCategoryClick?.('Commentary')} className="text-red-500 font-black text-sm mb-6 tracking-wider uppercase hover:underline">OPINION</button>
              <ul className="text-[11px] space-y-3 font-semibold text-gray-200">
                <li><button onClick={() => onCategoryClick?.('Commentary')} className="hover:text-red-400 transition-colors text-left">Brussels Calling</button></li>
                <li><button onClick={() => onCategoryClick?.('Commentary')} className="hover:text-red-400 transition-colors text-left">Columns</button></li>
                <li><button onClick={() => onCategoryClick?.('Commentary')} className="hover:text-red-400 transition-colors text-left">Guest Analysis</button></li>
                <li><button onClick={() => onCategoryClick?.('Commentary')} className="hover:text-red-400 transition-colors text-left">MEPs views</button></li>
                <li><button onClick={() => onCategoryClick?.('Commentary')} className="hover:text-red-400 transition-colors text-left">Polls and surveys</button></li>
              </ul>
            </div>
          </div>

          {/* Vertical Divider */}
          <div className="hidden lg:block w-px bg-white/10 self-stretch"></div>

          {/* Authors Column */}
          <div className="w-full lg:w-64">
            <h3 className="text-gray-300 font-black text-sm mb-6 tracking-wider uppercase">AUTHORS</h3>
            <div className="space-y-4">
              {[
                { name: 'Krzysztof Mularczyk', count: '32 articles', img: 'https://i.pravatar.cc/150?u=1' },
                { name: 'Carl Deconinck', count: '32 articles', img: 'https://i.pravatar.cc/150?u=2' },
                { name: 'Claire Lemaire', count: '32 articles', img: 'https://i.pravatar.cc/150?u=3' },
                { name: 'Chris Gatttringer', count: '32 articles', img: 'https://i.pravatar.cc/150?u=4' },
                { name: 'Chris Nelson', count: '32 articles', img: 'https://i.pravatar.cc/150?u=5' }
              ].map((author, i) => (
                <div key={i} className="flex items-center gap-3 group cursor-pointer">
                  <img src={author.img} className="w-8 h-8 rounded-full border border-white/20 group-hover:border-red-500 transition-colors" alt={author.name} />
                  <div>
                    <p className="text-[11px] font-bold leading-none group-hover:text-red-400 transition-colors">{author.name}</p>
                    <p className="text-[9px] text-gray-500 mt-0.5">{author.count}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Other Column */}
          <div className="w-full lg:w-32">
            <h3 className="text-gray-300 font-black text-sm mb-6 tracking-wider uppercase">OTHER</h3>
            <ul className="text-[11px] space-y-3 font-semibold text-gray-200">
              <li><button onClick={() => onCategoryClick?.('Videos')} className="hover:text-red-400 transition-colors text-left">Videos</button></li>
              <li><button onClick={() => onCategoryClick?.('Podcasts')} className="hover:text-red-400 transition-colors text-left">Podcasts</button></li>
              <li><button onClick={handleNewsletterNav} className="hover:text-red-400 transition-colors text-left">Newsletters</button></li>
              <li><button onClick={() => onCategoryClick?.('Politics')} className="hover:text-red-400 transition-colors text-left">Events</button></li>
              <li><button className="hover:text-red-400 transition-colors text-left">About Us</button></li>
            </ul>
          </div>
        </div>

        {/* Spotlight Bar */}
        <div className="bg-[#1a2a44]/80 p-3 rounded flex flex-wrap items-center gap-4 mb-12 border border-white/5">
          <span className="bg-white text-black px-2 py-0.5 text-[10px] font-black uppercase rounded-sm">IN THE SPOTLIGHT</span>
          <span className="text-[10px] text-gray-300 font-bold uppercase tracking-tight">WHAT'S DRIVING GLOBAL CONVERSATIONS.</span>
          <div className="flex flex-wrap gap-4 ml-2">
            {['#FrenchConfidenceVote', '#FarageDeportationPlan', '#UKImmigrationProtests', '#UkraineDefenseAid', '#EUUSTradeTensions'].map(tag => (
              <a key={tag} href="#" className="text-[11px] font-bold text-gray-200 hover:text-red-500 transition-colors">{tag}</a>
            ))}
          </div>
        </div>

        {/* Bottom Section: Videos & Podcasts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          
          {/* Left: Videos */}
          <div>
            <div className="flex justify-between items-center border-b border-white/10 pb-4 mb-8">
                <h2 className="text-xl font-black tracking-widest uppercase">VIDEOS</h2>
                <button onClick={() => onCategoryClick?.('Videos')} className="text-[10px] font-black hover:text-red-500">VIEW ALL</button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {[
                { title: 'Documentary: Free Speech Under Attack?', date: '27 August 2025', img: 'https://picsum.photos/seed/v1/300/200' },
                { title: 'Polska. Pelzajacy Zamach Stanu?', date: '27 August 2025', img: 'https://picsum.photos/seed/v2/300/200' },
                { title: 'Is Liberland the Next Crypto Paradise?', date: '27 August 2025', img: 'https://picsum.photos/seed/v3/300/200' },
                { title: 'US Opposes EU Tech Censorship', date: '27 August 2025', img: 'https://picsum.photos/seed/v4/300/200' },
                { title: 'Scientist fired for refusing to fly home', date: '27 August 2025', img: 'https://picsum.photos/seed/v5/300/200' },
                { title: 'Why did the Dutch Government fall and what happens next', date: '27 August 2025', img: 'https://picsum.photos/seed/v6/300/200' }
              ].map((vid, i) => (
                <div key={i} className="group cursor-pointer" onClick={() => onCategoryClick?.('Videos')}>
                  <div className="aspect-video relative overflow-hidden rounded mb-3 shadow-lg">
                    <img src={vid.img} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={vid.title} />
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors"></div>
                  </div>
                  <p className="text-[9px] font-bold mb-1 uppercase"><span className="text-red-500">Video</span> <span className="text-gray-400">{vid.date}</span></p>
                  <h4 className="text-[11px] font-bold leading-tight group-hover:text-red-400 transition-colors">{vid.title}</h4>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Podcasts */}
          <div>
            <div className="flex justify-between items-center border-b border-white/10 pb-4 mb-8">
                <h2 className="text-xl font-black tracking-widest uppercase">LATEST PODCASTS</h2>
                <button onClick={() => onCategoryClick?.('Podcasts')} className="text-[10px] font-black hover:text-red-500">VIEW ALL</button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {mockPodcasts.map((pod, i) => (
                <div key={i} className="group cursor-pointer" onClick={() => onPodcastClick?.(pod)}>
                  <div className="aspect-video relative overflow-hidden rounded mb-3 shadow-lg">
                    <img src={pod.imageUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={pod.title} />
                    <div className="absolute bottom-2 left-2 bg-red-600 text-[8px] font-black text-white px-1 py-0.5 rounded">PODCAST</div>
                  </div>
                  <p className="text-[9px] font-bold mb-1 uppercase"><span className="text-red-500">{pod.podcastSeries}</span> <span className="text-gray-400">{pod.date}</span></p>
                  <h4 className="text-[11px] font-bold leading-tight group-hover:text-red-400 transition-colors">{pod.title}</h4>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

export default MegaMenu;
