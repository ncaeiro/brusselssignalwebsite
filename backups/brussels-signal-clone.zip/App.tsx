
import React, { useState } from 'react';
import Header from './components/Header.tsx';
import Ticker from './components/Ticker.tsx';
import Hero from './components/Hero.tsx';
import SectionGrid from './components/SectionGrid.tsx';
import PhotoStories from './components/PhotoStories.tsx';
import WatchSection from './components/WatchSection.tsx';
import Footer from './components/Footer.tsx';
import VideoFeed from './components/VideoFeed.tsx';
import ArticleDetail from './components/ArticleDetail.tsx';
import PremiumArticleDetail from './components/PremiumArticleDetail.tsx';
import VideoArticleDetail from './components/VideoArticleDetail.tsx';
import PodcastArticleDetail from './components/PodcastArticleDetail.tsx';
import PodcastCategoryPage from './components/PodcastCategoryPage.tsx';
import NewsletterPage from './components/NewsletterPage.tsx';
import SubscriptionPlans from './components/SubscriptionPlans.tsx';
import CategoryPage from './components/CategoryPage.tsx';
import LoginModal from './components/LoginModal.tsx';
import SignUpModal from './components/SignUpModal.tsx';
import { NewsItem, VideoItem } from './types.ts';
import { MOST_READ, COMMENTARY, POLITICS, ECONOMY, SOCIETY, PHOTO_STORIES, WATCH_VIDEOS, FEATURED_ARTICLE } from './data.ts';

const App: React.FC = () => {
  const [view, setView] = useState<'home' | 'article' | 'premium' | 'subscriptions' | 'category' | 'video' | 'podcast' | 'podcast-category' | 'newsletters'>('home');
  const [selectedArticle, setSelectedArticle] = useState<NewsItem | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isSignUpModalOpen, setIsSignUpModalOpen] = useState(false);

  const navigateToHome = () => {
    setView('home');
    setSelectedArticle(null);
    setSelectedCategory('');
    window.scrollTo(0, 0);
  };

  const navigateToArticle = (article: NewsItem) => {
    setSelectedArticle(article);
    if (article.premium) {
      setView('premium');
    } else if (article.podcastSeries) {
      setView('podcast');
    } else if (article.category?.toLowerCase() === 'videos' || 'duration' in article) {
      setView('video');
    } else {
      setView('article');
    }
    window.scrollTo(0, 0);
  };

  const navigateToPremium = (article: NewsItem) => {
    setSelectedArticle(article);
    setView('premium');
    window.scrollTo(0, 0);
  };

  const navigateToVideo = (article: NewsItem) => {
    setSelectedArticle(article);
    setView('video');
    window.scrollTo(0, 0);
  };

  const navigateToPodcast = (article: NewsItem) => {
    setSelectedArticle(article);
    setView('podcast');
    window.scrollTo(0, 0);
  };

  const navigateToPodcastCategory = () => {
    setView('podcast-category');
    setSelectedArticle(null);
    setSelectedCategory('Podcasts');
    window.scrollTo(0, 0);
  };

  const navigateToNewsletters = () => {
    setView('newsletters');
    setSelectedArticle(null);
    setSelectedCategory('Newsletters');
    window.scrollTo(0, 0);
  };

  const navigateToSubscriptions = () => {
    setView('subscriptions');
    setSelectedArticle(null);
    setSelectedCategory('');
    window.scrollTo(0, 0);
  };

  const navigateToCategory = (categoryName: string) => {
    if (categoryName.toLowerCase() === 'podcasts' || categoryName.toLowerCase() === 'videos' || categoryName.toLowerCase() === 'newsletters') {
       if (categoryName.toLowerCase() === 'podcasts') {
         navigateToPodcastCategory();
       } else if (categoryName.toLowerCase() === 'newsletters') {
         navigateToNewsletters();
       } else {
         setSelectedCategory('Videos');
         setView('category');
       }
    } else {
      setSelectedCategory(categoryName);
      setView('category');
    }
    setSelectedArticle(null);
    window.scrollTo(0, 0);
  };

  const openLogin = () => {
    setIsSignUpModalOpen(false);
    setIsLoginModalOpen(true);
  };
  const closeLogin = () => setIsLoginModalOpen(false);

  const openSignUp = () => {
    setIsLoginModalOpen(false);
    setIsSignUpModalOpen(true);
  };
  const closeSignUp = () => setIsSignUpModalOpen(false);

  // Helper to get articles for the selected category
  const getCategoryArticles = (category: string): NewsItem[] => {
    const cat = category.toLowerCase();
    if (cat === 'politics') return POLITICS;
    if (cat === 'economy') return ECONOMY;
    if (cat === 'society') return SOCIETY;
    if (cat === 'commentary') return COMMENTARY;
    if (cat === 'photo stories') return PHOTO_STORIES;
    if (cat === 'videos') return WATCH_VIDEOS;
    return [];
  };

  return (
    <div className="min-h-screen flex flex-col relative">
      <Header 
        onLogoClick={navigateToHome} 
        onSignInClick={openLogin} 
        onBecomeMemberClick={navigateToSubscriptions}
        onCategoryClick={navigateToCategory}
        onPodcastClick={navigateToPodcast}
        onNewslettersClick={navigateToNewsletters}
      />
      <Ticker />
      
      {view === 'home' && (
        <main className="flex-grow container mx-auto px-4 md:px-6 lg:px-8 py-6">
          {/* Branded Top Promotion Banner */}
          <div className="mb-10 w-full cursor-pointer group" onClick={navigateToSubscriptions}>
              <div className="relative h-24 md:h-32 bg-[#1a2a44] rounded-lg overflow-hidden shadow-lg flex items-center border border-white/5">
                <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(circle_at_right,_var(--tw-gradient-stops))] from-red-600 via-transparent to-transparent"></div>
                <div className="relative z-10 w-full px-6 md:px-12 flex items-center justify-between gap-4">
                    <div className="flex-grow">
                        <div className="flex items-center gap-3 mb-2">
                            <span className="bg-red-600 text-white px-2 py-0.5 text-[9px] font-black uppercase tracking-widest rounded-sm">MEMBERSHIP</span>
                            <span className="text-white/40 text-[9px] font-black uppercase tracking-widest hidden sm:inline">INDEPENDENT JOURNALISM</span>
                        </div>
                        <h3 className="text-white text-xl md:text-2xl lg:text-3xl font-serif font-bold leading-tight">
                            Support the signal that challenges the noise.
                        </h3>
                    </div>
                    <div className="flex-shrink-0">
                        <button className="bg-white text-[#1a2a44] px-6 py-3 font-black text-[10px] md:text-xs uppercase tracking-[0.15em] rounded hover:bg-red-600 hover:text-white transition-all transform group-hover:scale-105 shadow-xl">
                            VIEW OFFERS
                        </button>
                    </div>
                </div>
              </div>
          </div>

          {/* Main Hero & Sidebars Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left: Most Read */}
            <aside className="lg:col-span-3 order-2 lg:order-1">
              <h2 className="text-xl font-bold border-b-2 border-red-600 pb-2 mb-4">Most Read</h2>
              <div className="space-y-6">
                {MOST_READ.map(item => (
                  <div key={item.id} className="flex gap-3 group cursor-pointer" onClick={() => navigateToArticle(item)}>
                    <img src={item.imageUrl} alt={item.title} className="w-24 h-16 object-cover flex-shrink-0" />
                    <div>
                      <h3 className="text-sm font-semibold leading-tight group-hover:text-blue-800 transition-colors">
                        {item.title}
                      </h3>
                      <p className="text-[10px] text-gray-500 mt-1 uppercase font-bold">
                          <span className="text-red-600">NEWS</span> {item.date}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-12">
                  <h2 className="text-xl font-bold border-b-2 border-red-600 pb-2 mb-4">Top Videos</h2>
                  <div className="grid grid-cols-2 lg:grid-cols-1 gap-4">
                       <div className="relative group cursor-pointer" onClick={() => navigateToVideo(WATCH_VIDEOS[0])}>
                          <img src="https://picsum.photos/seed/interview_1/400/300" className="w-full h-32 object-cover" />
                          <div className="absolute inset-0 flex items-center justify-center">
                              <div className="bg-red-600 rounded-full p-2 text-white">
                                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                              </div>
                          </div>
                          <h4 className="text-xs font-bold mt-2">Exclusive interview with Ribal Al-Assad</h4>
                       </div>
                       <div className="relative group cursor-pointer" onClick={() => navigateToVideo(WATCH_VIDEOS[1])}>
                          <img src="https://picsum.photos/seed/interview_2/400/300" className="w-full h-32 object-cover" />
                          <div className="absolute inset-0 flex items-center justify-center">
                              <div className="bg-red-600 rounded-full p-2 text-white">
                                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                              </div>
                          </div>
                          <h4 className="text-xs font-bold mt-2">Interview with Tim Murtaugh</h4>
                       </div>
                  </div>
              </div>
            </aside>

            {/* Center: Hero Story */}
            <div className="lg:col-span-6 order-1 lg:order-2">
              <Hero onClick={() => navigateToArticle(FEATURED_ARTICLE)} />
            </div>

            {/* Right: Commentary */}
            <aside className="lg:col-span-3 order-3">
              <div className="flex justify-between items-center border-b-2 border-red-600 pb-2 mb-4">
                <h2 className="text-xl font-bold">Commentary</h2>
                <button onClick={() => navigateToCategory('Commentary')} className="text-[10px] font-bold text-gray-500 hover:text-red-600">VIEW ALL</button>
              </div>
              <div className="space-y-6">
                {COMMENTARY.map(item => (
                  <div key={item.id} className="flex gap-3 group cursor-pointer" onClick={() => navigateToPremium(item)}>
                    <div className="flex-grow">
                      {item.premium && <span className="text-[10px] bg-red-600 text-white px-1 font-bold rounded">PREMIUM</span>}
                      <p className="text-xs font-bold text-red-600 mt-1 uppercase">{item.author}</p>
                      <h3 className="text-sm font-semibold leading-tight group-hover:text-blue-800 transition-colors">
                        {item.title}
                      </h3>
                      <p className="text-[10px] text-gray-500 mt-1 uppercase font-bold">
                          <span className="text-gray-400">COMMENTARY</span> {item.date}
                      </p>
                    </div>
                    <img src={item.imageUrl} alt={item.title} className="w-24 h-16 object-cover flex-shrink-0" />
                  </div>
                ))}
              </div>
              {/* Newsletter Side Box */}
              <div className="mt-8 bg-gray-100 p-4 border border-gray-200">
                  <h3 className="font-bold text-lg mb-2">Brussels Calling</h3>
                  <p className="text-xs text-gray-600 mb-4">The must-read morning briefing for anyone interested in European politics.</p>
                  <button onClick={navigateToNewsletters} className="w-full bg-red-600 text-white py-2 text-sm font-bold hover:bg-red-700 transition">SUBSCRIBE NOW</button>
              </div>
            </aside>
          </div>

          {/* Video Horizontal Section */}
          <section className="mt-12">
              <VideoFeed onItemClick={navigateToVideo} />
          </section>

          {/* Categories Section */}
          <section className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <SectionGrid title="Politics" items={POLITICS} onItemClick={navigateToArticle} onHeaderClick={() => navigateToCategory('Politics')} />
              <SectionGrid title="Economy" items={ECONOMY} onItemClick={navigateToArticle} onHeaderClick={() => navigateToCategory('Economy')} />
              <SectionGrid title="Society" items={SOCIETY} onItemClick={navigateToArticle} onHeaderClick={() => navigateToCategory('Society')} />
          </section>

          {/* Photo Stories Section */}
          <section className="mt-12">
              <PhotoStories items={PHOTO_STORIES} onItemClick={navigateToArticle} onHeaderClick={() => navigateToCategory('Photo Stories')} />
          </section>

          {/* Watch/Podcast Section */}
          <section className="mt-12">
              <WatchSection videos={WATCH_VIDEOS} onItemClick={navigateToVideo} onHeaderClick={() => navigateToCategory('Videos')} />
          </section>

          {/* Footer Banner - Linked to Newsletters */}
          <div className="mt-12 cursor-pointer group" onClick={navigateToNewsletters}>
              <div className="relative overflow-hidden rounded shadow-md border border-gray-200 h-44 flex items-center bg-[#1a2a44]">
                <img 
                    src="https://picsum.photos/seed/newsletter_footer_full/1200/400" 
                    alt="Brussels Signal Newsletters" 
                    className="absolute inset-0 w-full h-full object-cover opacity-40 transition-transform group-hover:scale-[1.05] duration-1000"
                />
                <div className="relative z-10 w-full px-8 flex flex-col md:flex-row items-center justify-between gap-8">
                    <div className="text-center md:text-left">
                        <div className="inline-block px-2 py-0.5 bg-red-600 text-[10px] font-black uppercase tracking-widest text-white mb-3">Newsletter Briefing</div>
                        <h3 className="text-white text-3xl md:text-4xl font-serif font-bold mb-2">The signals you need, in your inbox.</h3>
                        <p className="text-white/70 text-base font-medium">Daily briefings and weekly strategic analysis. Join 25,000+ readers today.</p>
                    </div>
                    <button className="bg-white text-[#1a2a44] px-10 py-5 font-black text-xs uppercase tracking-widest rounded shadow-xl group-hover:bg-red-600 group-hover:text-white transition-all transform group-hover:scale-105">
                        EXPLORE OUR NEWSLETTERS
                    </button>
                </div>
              </div>
          </div>
        </main>
      )}

      {view === 'article' && selectedArticle && <ArticleDetail article={selectedArticle} />}
      
      {view === 'premium' && selectedArticle && (
        <PremiumArticleDetail article={selectedArticle} onSignInClick={openLogin} />
      )}

      {view === 'video' && selectedArticle && (
        <VideoArticleDetail 
          article={selectedArticle as VideoItem} 
          onRelatedVideoClick={navigateToVideo}
        />
      )}

      {view === 'podcast' && selectedArticle && (
        <PodcastArticleDetail article={selectedArticle} />
      )}

      {view === 'podcast-category' && (
        <PodcastCategoryPage onPodcastClick={navigateToPodcast} />
      )}

      {view === 'newsletters' && (
        <NewsletterPage />
      )}

      {view === 'subscriptions' && (
        <SubscriptionPlans onPlanSelect={openSignUp} />
      )}

      {view === 'category' && (
        <CategoryPage 
          categoryName={selectedCategory} 
          articles={getCategoryArticles(selectedCategory)} 
          onArticleClick={navigateToArticle}
        />
      )}

      <Footer onSignInClick={openLogin} onBecomeMemberClick={navigateToSubscriptions} onCategoryClick={navigateToCategory} onNewslettersClick={navigateToNewsletters} />

      <LoginModal isOpen={isLoginModalOpen} onClose={closeLogin} onSwitchToSignUp={openSignUp} />
      <SignUpModal isOpen={isSignUpModalOpen} onClose={closeSignUp} onSwitchToLogin={openLogin} />
    </div>
  );
};

export default App;
