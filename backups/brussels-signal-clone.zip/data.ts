
import { NewsItem, VideoItem } from './types.ts';

export const FEATURED_ARTICLE: NewsItem = {
  id: 'featured-1',
  title: 'Poland rebuffs Trump suggestion that Russian drone incursion a ‘possible accident’',
  date: '12 SEP 2025',
  author: 'Krzysztof Mularczyk',
  imageUrl: 'https://picsum.photos/seed/diplomacy_hero/1200/675',
  summary: 'Polish Prime Minister Donald Tusk yesterday rejected speculation that the incursion into Polish airspace by around 20 Russian drones was accidental. “We are identifying those who, whether for political reasons, stupidity or betrayal, serve Russian propaganda and disinformation.”'
};

export const MOST_READ: NewsItem[] = [
  {
    id: 'm1',
    title: 'Nordic airports reopen as police probe mystery drones',
    date: '23 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/airport_security/400/250'
  },
  {
    id: 'm2',
    title: "'Conspiring' French journalist's wife 'subsidised by Socialist Party'",
    date: '23 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/french_politics/400/250'
  },
  {
    id: 'm3',
    title: 'Many thousands hit streets of Italy to protest \'Gaza genocide\'',
    date: '23 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/protest_italy/400/250'
  },
  {
    id: 'm4',
    title: 'Study shows Belgium needs eight new nuclear plants in \'optimal scenario\'',
    date: '22 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/nuclear_plant/400/250'
  }
];

export const COMMENTARY: NewsItem[] = [
  {
    id: 'c1',
    title: 'The reckoning is coming to France, the most spendthrift country in the world',
    author: 'Kevin Myers',
    date: '23 SEP 2025',
    premium: true,
    imageUrl: 'https://picsum.photos/seed/france_economy/400/250'
  },
  {
    id: 'c2',
    title: 'How the EU paid €1.7 billion to create false public opinion in Europe',
    author: 'Michał Karnowski',
    date: '22 SEP 2025',
    premium: true,
    imageUrl: 'https://picsum.photos/seed/eu_commission/400/250'
  },
  {
    id: 'c3',
    title: 'No military has yet learned how to face the danger of drones',
    author: 'Rafael Pinto Borges',
    date: '22 SEP 2025',
    premium: true,
    imageUrl: 'https://picsum.photos/seed/military_drone/400/250'
  }
];

export const POLITICS: NewsItem[] = [
  {
    id: 'p1',
    title: 'German State TV\'s US chief may lose visa over White House bigwig comments',
    date: '15 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/white_house/400/250'
  },
  {
    id: 'p2',
    title: 'US backs UN condemnation of Israeli strikes on Qatar',
    date: '12 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/united_nations/400/250'
  },
  {
    id: 'p3',
    title: 'Three years after Qatargate scandal broke, court cases still paralysed',
    date: '12 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/courtroom/400/250'
  }
];

export const ECONOMY: NewsItem[] = [
  {
    id: 'e1',
    title: 'Peace could save European economy — so why are EU leaders sabotaging it?',
    date: '11 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/euro_currency/400/250'
  },
  {
    id: 'e2',
    title: "'Western sanctions against Russia have had no effect,' says Kremlin",
    date: '10 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/kremlin/400/250'
  },
  {
    id: 'e3',
    title: 'Poland\'s financial rating questioned as result of hole in public finances',
    date: '9 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/poland_bank/400/250'
  }
];

export const SOCIETY: NewsItem[] = [
  {
    id: 's1',
    title: "'Vive la révolte!' Mélenchon calls for new French revolution",
    date: '8 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/revolt/400/250'
  },
  {
    id: 's2',
    title: "'Thousands of fake language and integration certificates circulating in Germany'",
    date: '10 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/germany_flag/400/250'
  },
  {
    id: 's3',
    title: 'More than half of Berlin police cadets \'need\' help',
    date: '8 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/berlin_police/400/250'
  }
];

export const PHOTO_STORIES: NewsItem[] = [
  {
    id: 'ph1',
    title: 'Russia and Ukraine exchange prisoners of war in Belarus',
    date: '25 AUG 2025',
    author: 'Claire Lemaire',
    imageUrl: 'https://picsum.photos/seed/prisoner_exchange/800/600'
  },
  {
    id: 'ph2',
    title: 'Thousands rally in Brussels to protest at Israeli actions in Gaza',
    date: '16 JUN 2025',
    author: 'Anne-Laure Dufeal',
    imageUrl: 'https://picsum.photos/seed/brussels_protest/800/600'
  },
  {
    id: 'ph3',
    title: 'Leo XIV elected: \'Habemus Papam — We have a Pope\'',
    date: '16 JUN 2025',
    author: 'Carl Deconinck',
    imageUrl: 'https://picsum.photos/seed/vatican/800/600'
  },
  {
    id: 'ph4',
    title: 'Goodbye, now-former German chancellor Scholz!',
    date: '9 MAY 2025',
    author: 'Carl Deconinck',
    imageUrl: 'https://picsum.photos/seed/scholz_exit/800/600'
  }
];

export const WATCH_VIDEOS: VideoItem[] = [
  {
    id: 'v1',
    title: "Macron still doesn't get it: All France agrees Macronism must go",
    author: 'Henry Olsen',
    date: '12 SEP 2025',
    duration: '60 SECONDS',
    imageUrl: 'https://picsum.photos/seed/macron_speech/600/900'
  },
  {
    id: 'v2',
    title: "Shanghai Blues: We risk losing more than money when pushing India to BRICS",
    author: 'Konstantinos Bogdanos',
    date: '12 SEP 2025',
    duration: '60 SECONDS',
    imageUrl: 'https://picsum.photos/seed/brics_summit/600/900'
  },
  {
    id: 'v3',
    title: "Au revoir, Bayou? What a Le Pen-Bardella tandem could mean for France",
    author: 'Rafael Pinto Borges',
    date: '12 SEP 2025',
    duration: '60 SECONDS',
    imageUrl: 'https://picsum.photos/seed/le_pen/600/900'
  },
  {
    id: 'v4',
    title: "Suppressing free speech and free votes: EU intent on crippling democratic resilience",
    author: 'Karl Pfefferkorn',
    date: '12 SEP 2025',
    duration: '60 SECONDS',
    imageUrl: 'https://picsum.photos/seed/voting_booth/600/900'
  },
  {
    id: 'v5',
    title: "Digital Euro: Privacy dream or surveillance nightmare?",
    author: 'Anne Lemaire',
    date: '10 SEP 2025',
    duration: '90 SECONDS',
    imageUrl: 'https://picsum.photos/seed/digital_currency/600/900'
  },
  {
    id: 'v6',
    title: "The Battle for the Arctic: NATO's new frontier",
    author: 'Carl Deconinck',
    date: '08 SEP 2025',
    duration: '120 SECONDS',
    imageUrl: 'https://picsum.photos/seed/nato_arctic/600/900'
  },
  {
    id: 'v7',
    title: "Energy Crisis 2.0: Is Europe prepared for a cold winter?",
    author: 'Krzysztof Mularczyk',
    date: '05 SEP 2025',
    duration: '45 SECONDS',
    imageUrl: 'https://picsum.photos/seed/energy_grid/600/900'
  },
  {
    id: 'v8',
    title: "Brussels' Power Grab: The end of national sovereignty?",
    author: 'Karl Pfefferkorn',
    date: '02 SEP 2025',
    duration: '60 SECONDS',
    imageUrl: 'https://picsum.photos/seed/brussels_parliament/600/900'
  }
];

export const INTERFERENCE_PODCASTS: NewsItem[] = [
  {
    id: 'p-int-1',
    title: 'The Battle for the Airwaves',
    podcastSeries: 'Interference',
    date: '14 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/pod_int_1/600/600',
    summary: 'Justin Stares and Alexandra Phillips discuss the latest in EU media interference and the fight for transparency.'
  },
  {
    id: 'p-int-2',
    title: 'Shadow Lobbying in the Bubble',
    podcastSeries: 'Interference',
    date: '08 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/pod_int_2/600/600',
    summary: 'Uncovering the hidden influencers who shape legislation in the European Parliament behind closed doors.'
  },
  {
    id: 'p-int-3',
    title: 'Censorship or Content Moderation?',
    podcastSeries: 'Interference',
    date: '01 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/pod_int_3/600/600',
    summary: 'A deep dive into the DSA and its implications for free speech across the continent.'
  }
];

export const HORIZON_PODCASTS: NewsItem[] = [
  {
    id: 'p-hor-1',
    title: 'Global Realignments and Europe',
    podcastSeries: 'Horizon Podcast',
    date: '12 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/pod_hor_1/600/600',
    summary: 'Ralph Schoellhammer looks at the shifting geopolitical sands and what they mean for the European project.'
  },
  {
    id: 'p-hor-2',
    title: 'The New Silk Road Dilemma',
    podcastSeries: 'Horizon Podcast',
    date: '05 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/pod_hor_2/600/600',
    summary: 'How Europe navigates Chinese investment while maintaining its strategic autonomy and security.'
  },
  {
    id: 'p-hor-3',
    title: 'Energy Security on the Horizon',
    podcastSeries: 'Horizon Podcast',
    date: '28 AUG 2025',
    imageUrl: 'https://picsum.photos/seed/pod_hor_3/600/600',
    summary: 'Exploring the long-term prospects for European energy independence in a post-fossil fuel world.'
  }
];

export const HAMMER_TIME_PODCASTS: NewsItem[] = [
  {
    id: 'p-ham-1',
    title: 'The Cost of Bureaucracy',
    podcastSeries: 'Hammer Time',
    date: '10 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/pod_ham_1/600/600',
    summary: 'Ralph Schoellhammer on why Brussels red tape is killing European industry and innovation.'
  },
  {
    id: 'p-ham-2',
    title: 'Agricultural Sovereignty',
    podcastSeries: 'Hammer Time',
    date: '01 SEP 2025',
    imageUrl: 'https://picsum.photos/seed/pod_ham_2/600/600',
    summary: 'Why the CAP reform is failing the local farmer and threatening the food security of the continent.'
  },
  {
    id: 'p-ham-3',
    title: 'Democracy Under Pressure',
    podcastSeries: 'Hammer Time',
    date: '22 AUG 2025',
    imageUrl: 'https://picsum.photos/seed/pod_ham_3/600/600',
    summary: 'A hard-hitting analysis of the centralization of power within the European Commission.'
  }
];
